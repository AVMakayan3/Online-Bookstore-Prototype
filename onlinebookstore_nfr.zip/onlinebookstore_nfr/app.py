from flask import Flask, render_template, redirect, url_for, flash, request, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from datetime import datetime
from flask_caching import Cache
from flask_talisman import Talisman
import logging_config
import logging




# --- CONFIGURATION (NFR-05: HTTPS enforcement would be done at deployment level) ---
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here' # Change this for production!
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bookstore.db' # NFR-02: Relational DB
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
Talisman(app, force_https=True, content_security_policy=None)


#--- Caching (NFR-01: Performance Optimization) ---
cache = Cache(app, config={
    "CACHE_TYPE": "simple",
    "CACHE_DEFAULT_TIMEOUT": 60,
    "CACHE_IGNORE_ERRORS": True
})


db = SQLAlchemy(app)
bcrypt = Bcrypt(app) # NFR-03: Secure Password Hashing
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# --- DATABASE MODELS (Step 4 of Instructions) ---

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    orders = db.relationship('Order', backref='customer', lazy=True)

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    isbn = db.Column(db.String(20), unique=True, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=True)
    image_url = db.Column(db.String(200), default='https://via.placeholder.com/150')

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='Processing')
    details = db.Column(db.Text, nullable=False) # Storing list of books as text for simplicity in MVP

# --- ROUTES ---

@app.route("/")
@app.route("/home")
@cache.cached(timeout=60)
def home():
    # FR-02 & FR-04: Browse and Search
    query = request.args.get('q')
    category = request.args.get('category')
    
    books_query = Book.query
    if query:
        # Search by Title, Author, or ISBN
        books_query = books_query.filter(
            (Book.title.contains(query)) | 
            (Book.author.contains(query)) | 
            (Book.isbn.contains(query))
        )
    if category:
        books_query = books_query.filter_by(category=category)
        
    books = books_query.all()
    categories = [r.category for r in db.session.query(Book.category).distinct()]
    return render_template('index.html', books=books, categories=categories)

# FR-01: Registration
@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(email=email, password=hashed_password)
        db.session.add(user)
        try:
            db.session.commit()
            flash('Account created! You can now log in.', 'success')
            return redirect(url_for('login'))
        except:
            flash('Email already exists.', 'danger')
    return render_template('register.html')

# FR-01: Login
@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Check email and password', 'danger')
    return render_template('login.html')

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))

# FR-03: Shopping Cart Logic (Using Session)
@app.route("/add_to_cart/<int:book_id>")
def add_to_cart(book_id):
    if 'cart' not in session:
        session['cart'] = []
    
    cart = session['cart']
    cart.append(book_id)
    session['cart'] = cart
    flash('Book added to cart!', 'success')
    return redirect(url_for('home'))

@app.route("/cart")
def cart():
    if 'cart' not in session or not session['cart']:
        return render_template('cart.html', books=[], total=0)
    
    cart_ids = session['cart']
    books = Book.query.filter(Book.id.in_(cart_ids)).all()
    
    # Calculate count per book for display
    display_books = []
    total = 0
    for book in books:
        count = cart_ids.count(book.id)
        display_books.append({'book': book, 'qty': count})
        total += book.price * count
        
    return render_template('cart.html', books=display_books, total=total)

@app.route("/clear_cart")
def clear_cart():
    session.pop('cart', None)
    return redirect(url_for('cart'))

# FR-04: Order Management
@app.route("/checkout", methods=['POST'])
@login_required
def checkout():
    if 'cart' not in session or not session['cart']:
        flash('Cart is empty', 'warning')
        return redirect(url_for('home'))
    
    cart_ids = session['cart']
    books = Book.query.filter(Book.id.in_(cart_ids)).all()
    total = sum(b.price * cart_ids.count(b.id) for b in books)
    
    # Create simple string summary of order
    details = ", ".join([f"{b.title} (x{cart_ids.count(b.id)})" for b in books])
    
    order = Order(user_id=current_user.id, total_price=total, details=details, status="Paid")
    db.session.add(order)
    db.session.commit()
    
    
    session.pop('cart', None)
    flash('Order placed successfully! (Simulation: Payment Processed)', 'success')
    return redirect(url_for('dashboard'))

@app.route("/dashboard")
@login_required
def dashboard():
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.date_posted.desc()).all()
    return render_template('dashboard.html', orders=orders)

# FR-05: Admin Functions
@app.route("/admin", methods=['GET', 'POST'])
@login_required
def admin():
    if not current_user.is_admin:
        flash('Access Denied', 'danger')
        return redirect(url_for('home'))
        
    if request.method == 'POST':
        # Add new book
        title = request.form.get('title')
        author = request.form.get('author')
        isbn = request.form.get('isbn')
        category = request.form.get('category')
        price = float(request.form.get('price'))
        
        book = Book(title=title, author=author, isbn=isbn, category=category, price=price)
        db.session.add(book)
        db.session.commit()
        flash('Book added to catalog', 'success')
        
    all_orders = Order.query.order_by(Order.date_posted.desc()).all()
    return render_template('admin.html', orders=all_orders)

# Initialize DB
with app.app_context():
    db.create_all()
    # Create a dummy admin if none exists
    if not User.query.filter_by(email='admin@obs.com').first():
        hashed_pw = bcrypt.generate_password_hash('admin123').decode('utf-8')
        admin_user = User(email='admin@obs.com', password=hashed_pw, is_admin=True)
        db.session.add(admin_user)
        
        # Seed some books
        b1 = Book(title="The Great Gatsby", author="F. Scott Fitzgerald", isbn="12345", category="Fiction", price=10.99)
        b2 = Book(title="Clean Code", author="Robert Martin", isbn="67890", category="Technology", price=29.99)
        db.session.add_all([admin_user, b1, b2])
        db.session.commit()


#--- Do not forget to set debug to False in production/presentation! ---
if __name__ == '__main__':
    app.run(debug=True)